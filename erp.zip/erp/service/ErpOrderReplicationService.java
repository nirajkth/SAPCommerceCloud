package org.training.core.erp.service;

import de.hybris.platform.core.model.order.OrderModel;

public interface ErpOrderReplicationService {

    /**
     * Replicates a placed Commerce order to the ERP system via SAP OData.
     *
     * @param order the Commerce OrderModel
     * @return ErpReplicationResult holding the outcome, ERP Sales Order ID, and status
     */
    ErpReplicationResult replicateOrder(OrderModel order);
}
