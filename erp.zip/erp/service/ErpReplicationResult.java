package org.training.core.erp.service;

import java.io.Serializable;

public class ErpReplicationResult implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum Status {
        SUCCESS,
        RETRY,
        FATAL_ERROR
    }

    private final Status status;
    private final String erpOrderCode;
    private final String message;
    private final int httpStatusCode;
    private final String idempotencyKey;

    public ErpReplicationResult(Status status, String erpOrderCode, String message, int httpStatusCode, String idempotencyKey) {
        this.status = status;
        this.erpOrderCode = erpOrderCode;
        this.message = message;
        this.httpStatusCode = httpStatusCode;
        this.idempotencyKey = idempotencyKey;
    }

    public static ErpReplicationResult success(String erpOrderCode, String idempotencyKey) {
        return new ErpReplicationResult(Status.SUCCESS, erpOrderCode, "Replicated successfully", 201, idempotencyKey);
    }

    public static ErpReplicationResult retry(String message, int httpStatusCode, String idempotencyKey) {
        return new ErpReplicationResult(Status.RETRY, null, message, httpStatusCode, idempotencyKey);
    }

    public static ErpReplicationResult fatal(String message, int httpStatusCode, String idempotencyKey) {
        return new ErpReplicationResult(Status.FATAL_ERROR, null, message, httpStatusCode, idempotencyKey);
    }

    public Status getStatus() {
        return status;
    }

    public String getErpOrderCode() {
        return erpOrderCode;
    }

    public String getMessage() {
        return message;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }

    public boolean isSuccess() {
        return Status.SUCCESS.equals(status);
    }

    public boolean isRetryable() {
        return Status.RETRY.equals(status);
    }

    @Override
    public String toString() {
        return "ErpReplicationResult{" +
                "status=" + status +
                ", erpOrderCode='" + erpOrderCode + '\'' +
                ", message='" + message + '\'' +
                ", httpStatusCode=" + httpStatusCode +
                ", idempotencyKey='" + idempotencyKey + '\'' +
                '}';
    }
}
