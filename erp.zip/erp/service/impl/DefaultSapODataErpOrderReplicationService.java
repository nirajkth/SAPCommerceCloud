package org.training.core.erp.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.enumeration.EnumerationService;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.Config;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.training.core.erp.odata.dto.SapODataErrorResponse;
import org.training.core.erp.odata.dto.SapODataResponseWrapper;
import org.training.core.erp.odata.dto.SapODataSalesOrderRequest;
import org.training.core.erp.odata.dto.SapODataSalesOrderResponse;
import org.training.core.erp.service.ErpOrderReplicationService;
import org.training.core.erp.service.ErpReplicationResult;

import java.nio.charset.StandardCharsets;
import java.util.*;

public class DefaultSapODataErpOrderReplicationService implements ErpOrderReplicationService {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultSapODataErpOrderReplicationService.class);

    private static final String PROP_BASE_URL = "erp.odata.base.url";
    private static final String PROP_USERNAME = "erp.odata.username";
    private static final String PROP_PASSWORD = "erp.odata.password";
    private static final String PROP_CONNECT_TIMEOUT = "erp.odata.connect.timeout";
    private static final String PROP_READ_TIMEOUT = "erp.odata.read.timeout";
    private static final String PROP_MAX_ATTEMPTS = "erp.odata.retry.maxAttempts";
    private static final String PROP_CSRF_ENABLED = "erp.odata.csrf.enabled";

    private static final String DEFAULT_BASE_URL = "http://localhost:8089/sap/opu/odata/sap/API_SALES_ORDER_SRV";

    private final ModelService modelService;
    private final EnumerationService enumerationService;
    private final Converter<OrderModel, SapODataSalesOrderRequest> erpOrderODataConverter;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // In-memory cached CSRF token and session cookies
    private String cachedCsrfToken;
    private List<String> cachedSessionCookies = new ArrayList<>();

    public DefaultSapODataErpOrderReplicationService(ModelService modelService,
                                                     EnumerationService enumerationService,
                                                     Converter<OrderModel, SapODataSalesOrderRequest> erpOrderODataConverter) {
        this.modelService = modelService;
        this.enumerationService = enumerationService;
        this.erpOrderODataConverter = erpOrderODataConverter;
    }

    @Override
    public ErpReplicationResult replicateOrder(OrderModel order) {
        if (order == null) {
            return ErpReplicationResult.fatal("Order is null", 400, null);
        }

        String orderCode = order.getCode();
        LOG.info("Initiating ERP replication for order [{}]", orderCode);

        // 1. Check or create Idempotency Key
        String idempotencyKey = (String) getSafeOrderProperty(order, "erpIdempotencyKey");
        if (StringUtils.isBlank(idempotencyKey)) {
            idempotencyKey = "HYB-" + orderCode + "-" + UUID.randomUUID().toString().substring(0, 8);
            setSafeOrderProperty(order, "erpIdempotencyKey", idempotencyKey);
        }

        // 2. Build OData Request Payload
        SapODataSalesOrderRequest odataPayload = erpOrderODataConverter.convert(order);

        // 3. Setup RestTemplate with timeouts
        RestTemplate restTemplate = createResilientRestTemplate();

        String baseUrl = Config.getString(PROP_BASE_URL, DEFAULT_BASE_URL);
        int maxAttempts = Config.getInt(PROP_MAX_ATTEMPTS, 3);
        boolean csrfEnabled = Config.getBoolean(PROP_CSRF_ENABLED, true);

        // 4. CSRF Handshake if needed
        if (csrfEnabled && cachedCsrfToken == null) {
            fetchCsrfToken(restTemplate, baseUrl);
        }

        // 5. Execution Loop with Retries
        ErpReplicationResult lastResult = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                LOG.info("Replicating order [{}] to ERP (Attempt {}/{})", orderCode, attempt, maxAttempts);

                HttpHeaders headers = createRequestHeaders(idempotencyKey, csrfEnabled);
                HttpEntity<SapODataSalesOrderRequest> requestEntity = new HttpEntity<>(odataPayload, headers);

                String postUrl = baseUrl.replaceAll("/+$", "") + "/A_SalesOrder";
                ResponseEntity<String> response = restTemplate.exchange(
                        postUrl,
                        HttpMethod.POST,
                        requestEntity,
                        String.class
                );

                if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                    // Success!
                    String responseBody = response.getBody();
                    SapODataSalesOrderResponse erpSalesOrder = parseSalesOrderResponse(responseBody);
                    String salesOrderNumber = erpSalesOrder != null ? erpSalesOrder.getSalesOrder() : null;

                    updateOrderSuccess(order, salesOrderNumber, idempotencyKey);
                    LOG.info("Successfully replicated order [{}] to ERP. Assigned SalesOrder: [{}]",
                            orderCode, salesOrderNumber);

                    return ErpReplicationResult.success(salesOrderNumber, idempotencyKey);
                }

            } catch (HttpStatusCodeException httpEx) {
                HttpStatus status = HttpStatus.resolve(httpEx.getStatusCode().value());
                String errorBody = httpEx.getResponseBodyAsString();
                String parsedErrorMsg = extractErrorMessage(errorBody);

                LOG.warn("ERP HTTP Error for order [{}]: Status [{}] Body: [{}]",
                        orderCode, status, parsedErrorMsg);

                // Handle CSRF expiration (403 Forbidden with CSRF error)
                if (status == HttpStatus.FORBIDDEN && csrfEnabled && attempt < maxAttempts) {
                    LOG.info("CSRF token expired. Refetching and retrying...");
                    cachedCsrfToken = null;
                    fetchCsrfToken(restTemplate, baseUrl);
                    continue;
                }

                // If transient (502, 503, 504) -> retryable
                if (status != null && (status == HttpStatus.SERVICE_UNAVAILABLE
                        || status == HttpStatus.GATEWAY_TIMEOUT
                        || status == HttpStatus.BAD_GATEWAY)) {

                    lastResult = ErpReplicationResult.retry(
                            "Transient ERP outage (" + status + "): " + parsedErrorMsg,
                            status.value(), idempotencyKey);

                    applyBackoff(attempt);
                    continue;
                }

                // If client validation error (400, 422) -> Fatal rejection
                updateOrderFailure(order, ErpReplicationResult.Status.FATAL_ERROR, parsedErrorMsg, idempotencyKey);
                return ErpReplicationResult.fatal("ERP rejected order: " + parsedErrorMsg,
                        httpEx.getStatusCode().value(), idempotencyKey);

            } catch (ResourceAccessException ioEx) {
                LOG.warn("Network / timeout exception connecting to ERP for order [{}]: {}",
                        orderCode, ioEx.getMessage());

                lastResult = ErpReplicationResult.retry("Network timeout: " + ioEx.getMessage(), 504, idempotencyKey);
                applyBackoff(attempt);

            } catch (Exception ex) {
                LOG.error("Unexpected error during ERP order replication for order [{}]", orderCode, ex);
                updateOrderFailure(order, ErpReplicationResult.Status.FATAL_ERROR, ex.getMessage(), idempotencyKey);
                return ErpReplicationResult.fatal("Unexpected error: " + ex.getMessage(), 500, idempotencyKey);
            }
        }

        // Exhausted retries
        String retryMsg = lastResult != null ? lastResult.getMessage() : "Exhausted retry attempts connecting to ERP";
        updateOrderFailure(order, ErpReplicationResult.Status.RETRY, retryMsg, idempotencyKey);
        return ErpReplicationResult.retry(retryMsg, 503, idempotencyKey);
    }

    private void fetchCsrfToken(RestTemplate restTemplate, String baseUrl) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-csrf-token", "Fetch");
            addBasicAuth(headers);

            String fetchUrl = baseUrl.replaceAll("/+$", "") + "/";
            HttpEntity<Void> request = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(fetchUrl, HttpMethod.GET, request, String.class);

            List<String> csrfHeader = response.getHeaders().get("x-csrf-token");
            if (csrfHeader != null && !csrfHeader.isEmpty()) {
                this.cachedCsrfToken = csrfHeader.get(0);
                LOG.info("Acquired fresh SAP CSRF token: {}", cachedCsrfToken);
            }

            List<String> setCookies = response.getHeaders().get(HttpHeaders.SET_COOKIE);
            if (setCookies != null) {
                this.cachedSessionCookies = setCookies;
            }
        } catch (Exception e) {
            LOG.warn("Unable to fetch CSRF token from ERP: {}", e.getMessage());
        }
    }

    private HttpHeaders createRequestHeaders(String idempotencyKey, boolean csrfEnabled) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("X-Idempotency-Key", idempotencyKey);
        headers.set("X-Correlation-ID", UUID.randomUUID().toString());

        addBasicAuth(headers);

        if (csrfEnabled && cachedCsrfToken != null) {
            headers.set("x-csrf-token", cachedCsrfToken);
        }

        if (cachedSessionCookies != null && !cachedSessionCookies.isEmpty()) {
            headers.put(HttpHeaders.COOKIE, cachedSessionCookies);
        }

        return headers;
    }

    private void addBasicAuth(HttpHeaders headers) {
        String user = Config.getString(PROP_USERNAME, "SAP_COMMERCE_USER");
        String pass = Config.getString(PROP_PASSWORD, "SecretPassword123");
        if (StringUtils.isNotBlank(user)) {
            String auth = user + ":" + pass;
            byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(StandardCharsets.UTF_8));
            headers.set(HttpHeaders.AUTHORIZATION, "Basic " + new String(encodedAuth));
        }
    }

    private RestTemplate createResilientRestTemplate() {
        int connectTimeout = Config.getInt(PROP_CONNECT_TIMEOUT, 5000);
        int readTimeout = Config.getInt(PROP_READ_TIMEOUT, 10000);

        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeout);
        factory.setReadTimeout(readTimeout);

        return new RestTemplate(factory);
    }

    private void applyBackoff(int attempt) {
        long backoffMs = (long) Math.pow(2, attempt) * 500L;
        try {
            Thread.sleep(backoffMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private SapODataSalesOrderResponse parseSalesOrderResponse(String responseJson) {
        try {
            SapODataResponseWrapper<SapODataSalesOrderResponse> wrapper = objectMapper.readValue(
                    responseJson,
                    objectMapper.getTypeFactory().constructParametricType(SapODataResponseWrapper.class, SapODataSalesOrderResponse.class)
            );
            return wrapper != null ? wrapper.getD() : null;
        } catch (Exception e) {
            LOG.warn("Could not deserialize OData response JSON: {}", e.getMessage());
            return null;
        }
    }

    private String extractErrorMessage(String errorJson) {
        if (StringUtils.isBlank(errorJson)) {
            return "No error details returned";
        }
        try {
            SapODataErrorResponse errorResponse = objectMapper.readValue(errorJson, SapODataErrorResponse.class);
            if (errorResponse != null && errorResponse.getError() != null && errorResponse.getError().getMessage() != null) {
                return errorResponse.getError().getMessage().getValue();
            }
        } catch (Exception ignored) {
        }
        return errorJson;
    }

    private void updateOrderSuccess(OrderModel order, String salesOrderNumber, String idempotencyKey) {
        setSafeOrderProperty(order, "erpOrderCode", salesOrderNumber);
        setSafeOrderProperty(order, "erpExportDate", new Date());
        setSafeOrderProperty(order, "erpExportError", null);
        setSafeOrderProperty(order, "erpIdempotencyKey", idempotencyKey);
        setSafeEnumProperty(order, "erpExportStatus", "EXPORTED");
        modelService.save(order);
    }

    private void updateOrderFailure(OrderModel order, ErpReplicationResult.Status status, String errorMessage, String idempotencyKey) {
        setSafeOrderProperty(order, "erpExportError", errorMessage);
        setSafeOrderProperty(order, "erpIdempotencyKey", idempotencyKey);
        String enumVal = status == ErpReplicationResult.Status.RETRY ? "RETRY" : "FAILED";
        setSafeEnumProperty(order, "erpExportStatus", enumVal);
        modelService.save(order);
    }

    private Object getSafeOrderProperty(OrderModel order, String attribute) {
        try {
            return modelService.getAttributeValue(order, attribute);
        } catch (Exception e) {
            return null;
        }
    }

    private void setSafeOrderProperty(OrderModel order, String attribute, Object value) {
        try {
            modelService.setAttributeValue(order, attribute, value);
        } catch (Exception e) {
            LOG.debug("Attribute {} not yet generated or available on OrderModel", attribute);
        }
    }

    private void setSafeEnumProperty(OrderModel order, String attribute, String enumCode) {
        try {
            Object enumValue = enumerationService.getEnumerationValue("ErpExportStatus", enumCode);
            modelService.setAttributeValue(order, attribute, enumValue);
        } catch (Exception e) {
            LOG.debug("Enum value ErpExportStatus.{} could not be assigned: {}", enumCode, e.getMessage());
        }
    }
}
