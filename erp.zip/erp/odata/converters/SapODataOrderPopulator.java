package org.training.core.erp.odata.converters;

import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.util.Config;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.training.core.erp.odata.dto.SapODataItemRequest;
import org.training.core.erp.odata.dto.SapODataSalesOrderRequest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SapODataOrderPopulator implements Populator<OrderModel, SapODataSalesOrderRequest> {

    private static final String DEFAULT_SALES_ORG = "erp.odata.salesOrg";
    private static final String DEFAULT_DIST_CHANNEL = "erp.odata.distChannel";
    private static final String DEFAULT_DIVISION = "erp.odata.division";
    private static final String DEFAULT_ORDER_TYPE = "erp.odata.orderType";

    @Override
    public void populate(OrderModel source, SapODataSalesOrderRequest target) throws ConversionException {
        if (source == null || target == null) {
            return;
        }

        target.setPurchaseOrderByCustomer(source.getCode());
        target.setSalesOrderType(Config.getString(DEFAULT_ORDER_TYPE, "OR"));
        target.setSalesOrganization(Config.getString(DEFAULT_SALES_ORG, "1000"));
        target.setDistributionChannel(Config.getString(DEFAULT_DIST_CHANNEL, "10"));
        target.setOrganizationDivision(Config.getString(DEFAULT_DIVISION, "00"));

        if (source.getUser() != null) {
            target.setSoldToParty(source.getUser().getUid());
        } else {
            target.setSoldToParty("ANONYMOUS");
        }

        if (source.getCurrency() != null) {
            target.setTransactionCurrency(source.getCurrency().getIsocode());
        }

        if (source.getTotalPrice() != null) {
            target.setTotalNetAmount(BigDecimal.valueOf(source.getTotalPrice()));
        }

        if (CollectionUtils.isNotEmpty(source.getEntries())) {
            List<SapODataItemRequest> items = new ArrayList<>();
            for (AbstractOrderEntryModel entry : source.getEntries()) {
                SapODataItemRequest item = new SapODataItemRequest();

                int entryIndex = entry.getEntryNumber() != null ? entry.getEntryNumber() + 1 : items.size() + 1;
                item.setSalesOrderItem(String.valueOf(entryIndex * 10));

                if (entry.getProduct() != null) {
                    item.setMaterial(entry.getProduct().getCode());
                }

                if (entry.getQuantity() != null) {
                    item.setRequestedQuantity(BigDecimal.valueOf(entry.getQuantity()));
                }

                if (entry.getUnit() != null && StringUtils.isNotBlank(entry.getUnit().getCode())) {
                    item.setRequestedQuantityUnit(entry.getUnit().getCode());
                } else {
                    item.setRequestedQuantityUnit("EA");
                }

                if (entry.getTotalPrice() != null) {
                    item.setNetAmount(BigDecimal.valueOf(entry.getTotalPrice()));
                }

                if (source.getCurrency() != null) {
                    item.setTransactionCurrency(source.getCurrency().getIsocode());
                }

                items.add(item);
            }
            target.setToItem(items);
        }
    }
}
