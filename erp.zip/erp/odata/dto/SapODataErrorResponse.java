package org.training.core.erp.odata.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SapODataErrorResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("error")
    private ODataErrorDetails error;

    public ODataErrorDetails getError() {
        return error;
    }

    public void setError(ODataErrorDetails error) {
        this.error = error;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ODataErrorDetails implements Serializable {
        private static final long serialVersionUID = 1L;

        @JsonProperty("code")
        private String code;

        @JsonProperty("message")
        private ErrorMessage message;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public ErrorMessage getMessage() {
            return message;
        }

        public void setMessage(ErrorMessage message) {
            this.message = message;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ErrorMessage implements Serializable {
        private static final long serialVersionUID = 1L;

        @JsonProperty("lang")
        private String lang;

        @JsonProperty("value")
        private String value;

        public String getLang() {
            return lang;
        }

        public void setLang(String lang) {
            this.lang = lang;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
}
