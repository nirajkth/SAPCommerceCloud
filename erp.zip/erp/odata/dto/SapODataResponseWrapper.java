package org.training.core.erp.odata.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SapODataResponseWrapper<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("d")
    private T d;

    public T getD() {
        return d;
    }

    public void setD(T d) {
        this.d = d;
    }
}
