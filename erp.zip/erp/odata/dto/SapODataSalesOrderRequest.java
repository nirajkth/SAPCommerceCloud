package org.training.core.erp.odata.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SapODataSalesOrderRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("SalesOrderType")
    private String salesOrderType = "OR";

    @JsonProperty("SalesOrganization")
    private String salesOrganization;

    @JsonProperty("DistributionChannel")
    private String distributionChannel;

    @JsonProperty("OrganizationDivision")
    private String organizationDivision;

    @JsonProperty("SoldToParty")
    private String soldToParty;

    @JsonProperty("PurchaseOrderByCustomer")
    private String purchaseOrderByCustomer;

    @JsonProperty("TransactionCurrency")
    private String transactionCurrency;

    @JsonProperty("TotalNetAmount")
    private BigDecimal totalNetAmount;

    @JsonProperty("to_Item")
    private List<SapODataItemRequest> toItem = new ArrayList<>();

    public String getSalesOrderType() {
        return salesOrderType;
    }

    public void setSalesOrderType(String salesOrderType) {
        this.salesOrderType = salesOrderType;
    }

    public String getSalesOrganization() {
        return salesOrganization;
    }

    public void setSalesOrganization(String salesOrganization) {
        this.salesOrganization = salesOrganization;
    }

    public String getDistributionChannel() {
        return distributionChannel;
    }

    public void setDistributionChannel(String distributionChannel) {
        this.distributionChannel = distributionChannel;
    }

    public String getOrganizationDivision() {
        return organizationDivision;
    }

    public void setOrganizationDivision(String organizationDivision) {
        this.organizationDivision = organizationDivision;
    }

    public String getSoldToParty() {
        return soldToParty;
    }

    public void setSoldToParty(String soldToParty) {
        this.soldToParty = soldToParty;
    }

    public String getPurchaseOrderByCustomer() {
        return purchaseOrderByCustomer;
    }

    public void setPurchaseOrderByCustomer(String purchaseOrderByCustomer) {
        this.purchaseOrderByCustomer = purchaseOrderByCustomer;
    }

    public String getTransactionCurrency() {
        return transactionCurrency;
    }

    public void setTransactionCurrency(String transactionCurrency) {
        this.transactionCurrency = transactionCurrency;
    }

    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    public void setTotalNetAmount(BigDecimal totalNetAmount) {
        this.totalNetAmount = totalNetAmount;
    }

    public List<SapODataItemRequest> getToItem() {
        return toItem;
    }

    public void setToItem(List<SapODataItemRequest> toItem) {
        this.toItem = toItem;
    }
}
