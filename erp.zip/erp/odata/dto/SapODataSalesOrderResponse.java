package org.training.core.erp.odata.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SapODataSalesOrderResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("SalesOrder")
    private String salesOrder;

    @JsonProperty("SalesOrderType")
    private String salesOrderType;

    @JsonProperty("PurchaseOrderByCustomer")
    private String purchaseOrderByCustomer;

    @JsonProperty("TotalNetAmount")
    private BigDecimal totalNetAmount;

    @JsonProperty("TransactionCurrency")
    private String transactionCurrency;

    @JsonProperty("OverallDeliveryStatus")
    private String overallDeliveryStatus;

    @JsonProperty("OverallSDProcessStatus")
    private String overallSDProcessStatus;

    public String getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(String salesOrder) {
        this.salesOrder = salesOrder;
    }

    public String getSalesOrderType() {
        return salesOrderType;
    }

    public void setSalesOrderType(String salesOrderType) {
        this.salesOrderType = salesOrderType;
    }

    public String getPurchaseOrderByCustomer() {
        return purchaseOrderByCustomer;
    }

    public void setPurchaseOrderByCustomer(String purchaseOrderByCustomer) {
        this.purchaseOrderByCustomer = purchaseOrderByCustomer;
    }

    public BigDecimal getTotalNetAmount() {
        return totalNetAmount;
    }

    public void setTotalNetAmount(BigDecimal totalNetAmount) {
        this.totalNetAmount = totalNetAmount;
    }

    public String getTransactionCurrency() {
        return transactionCurrency;
    }

    public void setTransactionCurrency(String transactionCurrency) {
        this.transactionCurrency = transactionCurrency;
    }

    public String getOverallDeliveryStatus() {
        return overallDeliveryStatus;
    }

    public void setOverallDeliveryStatus(String overallDeliveryStatus) {
        this.overallDeliveryStatus = overallDeliveryStatus;
    }

    public String getOverallSDProcessStatus() {
        return overallSDProcessStatus;
    }

    public void setOverallSDProcessStatus(String overallSDProcessStatus) {
        this.overallSDProcessStatus = overallSDProcessStatus;
    }
}
